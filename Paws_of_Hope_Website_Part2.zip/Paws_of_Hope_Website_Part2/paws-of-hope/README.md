# Paws of Hope Animal Rescue – Website Project

**Student:** Dipolelo Pretty Dikgake  
**Student Number:** ST10501461  
**Group:** 01  
**Subject:** Web Development (WEDE5020)  
**Current Part:** Part 2 – Designing the Visuals (CSS Styling and Responsive Design)

---

## Project Overview

This repository contains the website for **Paws of Hope Animal Rescue**, a hypothetical non-profit animal rescue organisation based in Johannesburg, South Africa.

The website aims to:
- Showcase animals available for adoption
- Encourage donations and sponsorships
- Recruit volunteers and foster carers
- Provide information about the organisation

---

## Website Goals and Objectives

1. Increase successful adoptions through clear animal profiles and an online application form
2. Generate online donations and recurring support
3. Recruit volunteers and foster homes
4. Educate the public about responsible pet ownership

---

## Key Features

### Part 1
- Homepage with impact statistics and calls-to-action
- About Us page (history, mission, vision, team)
- Animals for Adoption page with sample profiles
- Get Involved page with adoption, volunteer and donation enquiry forms
- Contact page with details and contact form
- Consistent navigation across all pages
- Semantic HTML5 structure
- Organised file and folder structure

### Part 2
- External CSS stylesheet (`css/styles.css`) linked to all pages
- Brand colour scheme (terracotta, sage green, cream, charcoal)
- Typography styling (serif headings, clean body text)
- Layout using Flexbox and CSS Grid
- Visual styles (shadows, borders, rounded corners, hover effects)
- Responsive design with media queries for tablet and mobile
- Relative units (rem) and fluid images

---

## File Structure

```
paws-of-hope/
├── index.html          # Homepage
├── about.html          # About Us
├── animals.html        # Animals for Adoption
├── enquiry.html        # Get Involved / Forms
├── contact.html        # Contact
├── css/
│   └── styles.css      # Full Part 2 stylesheet
├── js/
│   └── main.js         # Placeholder for Part 3
├── images/
│   └── animals/        # Individual animal photos
├── screenshots/
│   ├── desktop-view.jpg
│   ├── tablet-view.jpg
│   └── mobile-view.jpg
└── README.md
```

---

## Colour Scheme (from Proposal)

| Colour     | Hex       | Usage                    |
|------------|-----------|--------------------------|
| Terracotta | `#C2703A` | Primary accent, buttons  |
| Sage Green | `#7A9E7E` | Secondary accent, hover  |
| Cream      | `#F8F4EF` | Page background          |
| Charcoal   | `#333333` | Text and footer          |

---

## Responsive Breakpoints

| Device  | Breakpoint     | Layout changes                          |
|---------|----------------|-----------------------------------------|
| Desktop | > 900px        | Full multi-column, horizontal nav       |
| Tablet  | ≤ 900px        | Stacked header, 2-column stats          |
| Mobile  | ≤ 600px        | Single column, vertical navigation      |

---

## Sitemap

- Home (`index.html`)
- About Us (`about.html`)
- Animals (`animals.html`)
- Get Involved (`enquiry.html`)
- Contact (`contact.html`)

---

## Changelog

### Part 1
- **2026-08** – Initial project structure created
- **2026-08** – All five HTML pages built with semantic structure and navigation
- **2026-08** – Content from research package integrated
- **2026-08** – Placeholder CSS and JS files added
- **2026-08** – README.md created
- **2026-08** – Images from Pexels added and linked in HTML

### Part 2
- **2026-09** – Created full external stylesheet (`css/styles.css`)
- **2026-09** – Applied CSS reset and CSS custom properties (variables) for colour scheme
- **2026-09** – Implemented base styles, typography, header/navigation and footer
- **2026-09** – Added Flexbox layout for header and Grid for statistics section
- **2026-09** – Styled animal cards, forms, buttons and hover/focus states
- **2026-09** – Implemented responsive design with media queries (900px and 600px breakpoints)
- **2026-09** – Used relative units (rem) and fluid images for responsiveness
- **2026-09** – Updated README.md with Part 2 information, colour scheme and breakpoints
- **2026-09** – Added screenshot evidence of desktop, tablet and mobile views

---

## Testing Notes (Part 2)

The website has been tested on different screen sizes. Screenshot evidence is included below.

### Desktop view
![Desktop view](screenshots/desktop-view.jpg)

### Tablet view
![Tablet view](screenshots/tablet-view.jpg)

### Mobile view
![Mobile view](screenshots/mobile-view.jpg)

**How to test:**  
Open any HTML page in a browser → press F12 (Developer Tools) → click the device toolbar icon → select different device sizes to view the responsive layout.

---

## References

- Content developed from the approved Website Project Proposal for Paws of Hope Animal Rescue
- Pexels. (n.d.). Free stock photographs. Available at: https://www.pexels.com (Accessed: 13 August 2026).
- Assignment brief: IIE Web Development (WEDE5020) – Part 1 and Part 2 requirements
- MDN Web Docs – CSS Flexbox, CSS Grid and Media Queries (for technical reference)
