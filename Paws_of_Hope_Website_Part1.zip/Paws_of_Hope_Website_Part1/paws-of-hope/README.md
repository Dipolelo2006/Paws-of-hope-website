# Paws of Hope Animal Rescue – Website Project

**Student:** Dipolelo Pretty Dikgake  
**Student Number:** ST10501461  
**Group:** 01  
**Subject:** Web Development (WEDE5020)  
**Part:** Part 1 – Building the Foundation  

---

## Project Overview

This repository contains the Part 1 deliverables for a website built for **Paws of Hope Animal Rescue**, a hypothetical non-profit animal rescue organisation based in Johannesburg, South Africa.

The website aims to:
- Showcase animals available for adoption
- Encourage donations and sponsorships
- Recruit volunteers and foster carers
- Provide information about the organisation

---

## Website Goals and Objectives

1. Increase successful adoptions through clear animal profiles and an online application form
2. Generate online donations and recurring support
3. Recruit volunteers and foster homes
4. Educate the public about responsible pet ownership

---

## Key Features (Part 1)

- Homepage with impact statistics and calls-to-action
- About Us page (history, mission, vision, team)
- Animals for Adoption page with sample profiles
- Get Involved page with adoption, volunteer and donation enquiry forms
- Contact page with details and contact form
- Consistent navigation across all pages
- Semantic HTML5 structure
- Organised file and folder structure

---

## File Structure

```
paws-of-hope/
├── index.html          # Homepage
├── about.html          # About Us
├── animals.html        # Animals for Adoption
├── enquiry.html        # Get Involved / Forms
├── contact.html        # Contact
├── css/
│   └── styles.css      # Placeholder for Part 2
├── js/
│   └── main.js         # Placeholder for Part 3
├── images/
│   └── animals/        # Animal photos will go here
└── README.md
```

---

## Timeline and Milestones (Part 1)

- Proposal submitted and approved
- Content research completed
- HTML structure and navigation created
- Content integrated into pages
- Repository set up with initial commits

---

## Part 1 Details

This submission covers **Part 1 only**.  
Part 2 (CSS styling) and Part 3 (JavaScript functionality) will be added in future submissions.

---

## Sitemap

- Home (`index.html`)
- About Us (`about.html`)
- Animals (`animals.html`)
- Get Involved (`enquiry.html`)
- Contact (`contact.html`)

---

## Changelog

- **2026-08** – Initial project structure created
- **2026-08** – All five HTML pages built with semantic structure and navigation
- **2026-08** – Content from research package integrated
- **2026-08** – Placeholder CSS and JS files added
- **2026-08** – README.md created

---

## References

- Content developed from the approved Website Project Proposal for Paws of Hope Animal Rescue
- Image sources (to be added): Unsplash, Pexels, Pixabay (free stock)
- Assignment brief: IIE Web Development (WEDE5020) – Part 1 requirements

---

*This is an academic project created for educational purposes.*
