# Research Log – Paws of Hope Animal Rescue

**Student:** Dipolelo Pretty Dikgake  
**Student Number:** ST10501461  
**Organisation:** Paws of Hope Animal Rescue (approved)  
**Date started:** August 2026

---

## 1. Organisation Research

Because Paws of Hope is a hypothetical organisation created for this academic project, primary information was developed from the approved Website Project Proposal and realistic South African animal-welfare practices.

Secondary research drew on publicly available information from:
- Typical operations of registered animal rescue NPOs in Gauteng
- General statistics and best practices published by the NSPCA and similar bodies
- Common website structures used by successful South African animal shelters

## 2. Content Sources Used

| Content Type          | Source                                      | Notes                                      |
|-----------------------|---------------------------------------------|--------------------------------------------|
| Organisation overview | Original content based on approved proposal | Written for this project                   |
| Mission & Vision      | Original content                            | Aligned with proposal                      |
| Animal profiles       | Original realistic examples                 | For academic demonstration                 |
| Adoption process      | Standard practice in SA animal welfare      | Adapted for clarity                        |
| Contact & forms       | Original content                            | Matches required pages                     |
| Images                | Unsplash, Pexels, Pixabay                   | See images/sources.txt                     |

## 3. File Organisation

```
content-research/
├── text/                  ← All written content for the 5 pages
│   ├── homepage-copy.txt
│   ├── about-copy.txt
│   ├── animals-profiles.txt
│   ├── enquiry-forms.txt
│   └── contact-info.txt
├── images/
│   └── sources.txt        ← Legal free image sources + suggested filenames
└── notes/
    └── research-log.md    ← This file
```

## 4. Next Steps After This Package

1. Select and download images from the recommended sources.
2. Place chosen images into the project’s `images/` folder (and `images/animals/` subfolder).
3. Integrate the text content into the HTML pages.
4. Keep a record of every image URL and licence for the final README.md references.

## 5. Notes

- All text content is original and written specifically for this Part 1 submission.
- No copyrighted material from real organisations has been copied.
- Image recommendations are strictly free-to-use stock sources.
