CONTENT RESEARCH PACKAGE
Paws of Hope Animal Rescue
Part 1 – Building the Foundation
================================

Student: Dipolelo Pretty Dikgake
Student Number: ST10501461
Group: 01
Subject: Web Development (WEDE5020)

This folder contains all researched content required for the Content Research and Sourcing submission (ZIP file).

FOLDER STRUCTURE
----------------
text/          → Written content ready to place into HTML pages
images/        → Image sourcing list and recommended free sources
notes/         → Research log and process notes

HOW TO USE
----------
1. Read the text files and copy the relevant content into each HTML page.
2. Download free images from the sites listed in images/sources.txt.
3. Keep a record of image credits for the project README.md.
4. Zip this entire “content-research” folder and submit as required.

All content is original and prepared specifically for this academic project.
